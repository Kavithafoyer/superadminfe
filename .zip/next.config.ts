import path from "path";
import type { NextConfig } from "next";

const nextConfig: any = {
  transpilePackages: ['@foyer/crm-core'],
  outputFileTracingRoot: path.resolve(__dirname, '../../'),
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
};

export default nextConfig;
