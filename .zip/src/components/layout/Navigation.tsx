'use client';

import React, { useState } from 'react';
import { usePathname } from 'next/navigation';
import { NavLink } from './NavLink';
import {
  LayoutDashboard,
  Table,
  FileText,
  User,
  Settings,
  Shield,
  Layers,
  ChevronDown,
  BarChart3,
  CreditCard,
  Building2,
} from 'lucide-react';
import { useStore } from '@/store/useStore';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'motion/react';

export interface MenuItem {
  icon?: React.ElementType;
  label: string;
  path: string;
  subItems?: MenuItem[];
}

export interface MenuSection {
  title?: string;
  items: MenuItem[];
}

export const getMenuGroups = (): MenuSection[] => [
  {
    title: 'Dashboards',
    items: [
      {
        icon: LayoutDashboard,
        label: 'SuperAdmin Overview',
        path: '/',
      },
      {
        icon: BarChart3,
        label: 'Analytics Dashboard',
        path: '/analytics-dashboard',
      },
    ],
  },
  {
    title: 'Operations & Forms',
    items: [
      {
        icon: FileText,
        label: 'SuperAdmin Forms',
        path: '/forms',
      },
      {
        icon: Table,
        label: 'Accounts & Records',
        path: '/tables',
      },
    ],
  },
  {
    title: 'Administration',
    items: [
      {
        icon: User,
        label: 'Profile',
        path: '/profile',
      },
      {
        icon: Settings,
        label: 'Platform Settings',
        path: '/settings',
      },
    ],
  },
];

export function Navigation({ collapsed = false, onNavigate }: { collapsed?: boolean; onNavigate?: () => void }) {
  const pathname = usePathname();
  const { primaryColor } = useStore();
  const [expandedMenus, setExpandedMenus] = useState<string[]>([]);

  const menuSections = React.useMemo(() => getMenuGroups(), []);

  const toggleSubmenu = (label: string) => {
    setExpandedMenus((prev) =>
      prev.includes(label) ? prev.filter((item) => item !== label) : [...prev, label]
    );
  };

  return (
    <nav className="flex flex-col gap-6 py-2">
      {menuSections.map((section, idx) => (
        <div key={idx} className="flex flex-col gap-1.5">
          {section.title && !collapsed && (
            <span className="px-3 text-[11px] font-bold text-muted-foreground/70 uppercase tracking-wider">
              {section.title}
            </span>
          )}

          <div className="flex flex-col gap-1">
            {section.items.map((item) => {
              const Icon = item.icon || Layers;
              const hasSubItems = item.subItems && item.subItems.length > 0;
              const isExpanded = expandedMenus.includes(item.label);
              const isActive = pathname === item.path || (hasSubItems && item.subItems?.some((sub) => pathname === sub.path));

              if (hasSubItems && !collapsed) {
                return (
                  <div key={item.label} className="flex flex-col">
                    <button
                      type="button"
                      onClick={() => toggleSubmenu(item.label)}
                      className={cn(
                        "flex items-center justify-between w-full px-3 py-2 text-sm font-medium rounded-lg transition-colors cursor-pointer",
                        isActive
                          ? "bg-primary/10 text-primary font-semibold"
                          : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60"
                      )}
                    >
                      <div className="flex items-center gap-3">
                        <Icon className="h-4 w-4" />
                        <span>{item.label}</span>
                      </div>
                      <ChevronDown
                        className={cn(
                          "h-4 w-4 transition-transform duration-200",
                          isExpanded ? "transform rotate-180" : ""
                        )}
                      />
                    </button>

                    <AnimatePresence initial={false}>
                      {isExpanded && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden pl-7 pt-1 flex flex-col gap-1"
                        >
                          {item.subItems?.map((sub) => (
                            <NavLink
                              key={sub.path}
                              href={sub.path}
                              onClick={onNavigate}
                              className={cn(
                                "text-xs py-1.5 px-3 rounded-md transition-colors",
                                pathname === sub.path
                                  ? "text-primary font-bold bg-primary/5"
                                  : "text-muted-foreground hover:text-foreground hover:bg-slate-100/50 dark:hover:bg-slate-800/40"
                              )}
                            >
                              {sub.label}
                            </NavLink>
                          ))}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              }

              return (
                <NavLink
                  key={item.path}
                  href={item.path}
                  icon={Icon}
                  collapsed={collapsed}
                  onClick={onNavigate}
                  active={pathname === item.path}
                >
                  {item.label}
                </NavLink>
              );
            })}
          </div>
        </div>
      ))}
    </nav>
  );
}
