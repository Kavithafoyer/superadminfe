import { createSlice } from '@reduxjs/toolkit';

interface AuthState {
  isAuthenticated: boolean;
}

const getInitialState = (): AuthState => {
  if (typeof window !== 'undefined') {
    try {
      const persisted = sessionStorage.getItem('auth-storage');
      if (persisted) {
        const parsed = JSON.parse(persisted);
        if (parsed && parsed.state && typeof parsed.state.isAuthenticated === 'boolean') {
          return { isAuthenticated: parsed.state.isAuthenticated };
        }
      }
    } catch (e) {
      console.error(e);
    }
  }
  return { isAuthenticated: false };
};

const authSlice = createSlice({
  name: 'auth',
  initialState: getInitialState(),
  reducers: {
    login: (state) => {
      state.isAuthenticated = true;
      if (typeof window !== 'undefined') {
        sessionStorage.setItem('auth-storage', JSON.stringify({ state: { isAuthenticated: true } }));
      }
    },
    logout: (state) => {
      state.isAuthenticated = false;
      if (typeof window !== 'undefined') {
        localStorage.removeItem('token');
        localStorage.removeItem('refreshToken');
        localStorage.removeItem('designation');
        localStorage.removeItem('selectedChild');
        localStorage.removeItem('childrenList');
        localStorage.removeItem('ParentEmail');
        sessionStorage.removeItem('auth-storage');
      }
    },
  },
});

export const { login, logout } = authSlice.actions;
export default authSlice.reducer;
