'use client';

import React, { useState } from 'react';
import {
  RefreshCw,
  TrendingUp,
  CreditCard,
  Layers,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  DollarSign,
  Activity,
  FileText,
  Server,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import {
  useGetRevenueForecastDashboardQuery,
  useGetPaymentDashboardAnalyticsQuery,
  useGetRenewalDashboardAnalyticsQuery,
  useGetRenewalFunnelAnalyticsQuery,
  useGetCancellationOverviewAnalyticsQuery,
  useGetPlanAdoptionDashboardAnalyticsQuery,
  useGetTopPlansDistributionAnalyticsQuery,
  useGetRequestOperationsDashboardQuery,
  MOCK_REVENUE_FORECAST,
  MOCK_PAYMENT_HIGHLIGHTS,
  MOCK_TOP_PLANS,
  MOCK_RENEWAL_FUNNEL,
  MOCK_REQUEST_DISTRIBUTION,
  MOCK_PLAN_ADOPTION,
  MOCK_RENEWAL_ANALYTICS,
  MOCK_CANCELLATION_ANALYTICS,
} from '@/service/api/superAdminService';

const Rupee = '₹';

const formatMonth = (monthStr: string) => {
  if (!monthStr) return '';
  const parts = monthStr.split('-');
  if (parts.length < 2) return monthStr;
  const monthNames = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
  ];
  const monthIndex = parseInt(parts[1], 10) - 1;
  return `${monthNames[monthIndex] || parts[1]} ${parts[0]}`;
};

const PLAN_COLORS = ['#147659', '#3686ff', '#ffa14e', '#7c47f7', '#ff6b77', '#2bb673', '#31d9ff'];
const REQUEST_COLORS = ['#ffa14e', '#7c47f7', '#3686ff', '#147659'];

export default function AnalyticsDashboardPage() {
  const [viewType, setViewType] = useState<'mrr' | 'arr'>('mrr');
  const [activeAdoptionTab, setActiveAdoptionTab] = useState<'adoption' | 'renewals' | 'cancellations'>('adoption');

  // RTK Query API Hooks
  const {
    data: revenueData,
    isLoading: loadingRevenue,
    isError: errorRevenue,
    refetch: refetchRevenue,
  } = useGetRevenueForecastDashboardQuery();

  const {
    data: paymentData,
    isLoading: loadingPayment,
    isError: errorPayment,
    refetch: refetchPayment,
  } = useGetPaymentDashboardAnalyticsQuery();

  const {
    data: renewalData,
    isLoading: loadingRenewal,
    isError: errorRenewal,
    refetch: refetchRenewal,
  } = useGetRenewalDashboardAnalyticsQuery();

  const {
    data: funnelData,
    isLoading: loadingFunnel,
    isError: errorFunnel,
    refetch: refetchFunnel,
  } = useGetRenewalFunnelAnalyticsQuery();

  const {
    data: cancellationData,
    isLoading: loadingCancellation,
    isError: errorCancellation,
    refetch: refetchCancellation,
  } = useGetCancellationOverviewAnalyticsQuery();

  const {
    data: adoptionData,
    isLoading: loadingAdoption,
    isError: errorAdoption,
    refetch: refetchAdoption,
  } = useGetPlanAdoptionDashboardAnalyticsQuery();

  const {
    data: plansData,
    isLoading: loadingPlans,
    isError: errorPlans,
    refetch: refetchPlans,
  } = useGetTopPlansDistributionAnalyticsQuery();

  const {
    data: requestData,
    isLoading: loadingRequest,
    isError: errorRequest,
    refetch: refetchRequest,
  } = useGetRequestOperationsDashboardQuery();

  const revenue = revenueData || MOCK_REVENUE_FORECAST;
  const payment = paymentData || MOCK_PAYMENT_HIGHLIGHTS;
  const renewal = renewalData || MOCK_RENEWAL_ANALYTICS;
  const funnel = funnelData || MOCK_RENEWAL_FUNNEL;
  const cancellation = cancellationData || MOCK_CANCELLATION_ANALYTICS;
  const adoption = adoptionData || MOCK_PLAN_ADOPTION;
  const plans = plansData || MOCK_TOP_PLANS;
  const request = requestData || MOCK_REQUEST_DISTRIBUTION;

  const handleRefetchAll = () => {
    refetchRevenue();
    refetchPayment();
    refetchRenewal();
    refetchFunnel();
    refetchCancellation();
    refetchAdoption();
    refetchPlans();
    refetchRequest();
  };

  // Process revenue forecast chart data
  const currentMrr = revenue?.current_mrr || 0;
  const currentArr = revenue?.current_arr || 0;
  const trendData = viewType === 'mrr' ? revenue?.mrr_trend || [] : revenue?.arr_trend || [];
  const chartPoints = trendData.map((item: any) => ({
    rawMonth: item.month,
    formattedMonth: formatMonth(item.month),
    amount: viewType === 'mrr' ? item.mrr : item.arr,
  }));

  // Top plans chart data
  const topPlansItems = (plans?.labels || []).map((label: string, idx: number) => ({
    name: label,
    count: plans.counts[idx] || 0,
  }));
  const totalPlanSubscriptions = (plans?.counts || []).reduce((acc, curr) => acc + curr, 0);

  // Request distribution data
  const requestDistributionItems = (request?.request_distribution || []).map((item) => ({
    name: item.module,
    value: item.count,
  }));

  const invoiceTotal = (request?.invoice_generated_requests || 0) + (request?.pending_invoice_requests || 0);
  const invoicePercentage = invoiceTotal > 0 ? Math.round(((request?.invoice_generated_requests || 0) / invoiceTotal) * 100) : 0;

  const instanceTotal = (request?.instance_created || 0) + (request?.instance_pending || 0);
  const instancePercentage = instanceTotal > 0 ? Math.round(((request?.instance_created || 0) / instanceTotal) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100">
            Analytics & Reports Overview
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Real-time financial, subscription adoption, and cloud operational telemetry.
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handleRefetchAll}
          className="gap-2 text-xs font-semibold border-emerald-600 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 cursor-pointer self-start sm:self-auto"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          Refresh All
        </Button>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════
          PAYMENT HIGHLIGHTS (5 STAT CARDS - EXACT superadminfe DESIGN)
      ═══════════════════════════════════════════════════════════════════ */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {/* TOTAL INVOICED */}
        <Card className="shadow-xs border-slate-200 dark:border-slate-800">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                TOTAL INVOICED
              </p>
              <h3 className="text-xl font-extrabold text-slate-900 dark:text-slate-100 mt-1">
                {Rupee} {payment.total_invoiced?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </h3>
            </div>
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400">
              <DollarSign className="w-5 h-5" />
            </div>
          </CardContent>
        </Card>

        {/* OUTSTANDING AMOUNT */}
        <Card className="shadow-xs border-slate-200 dark:border-slate-800">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                OUTSTANDING AMOUNT
              </p>
              <h3 className="text-xl font-extrabold text-amber-600 dark:text-amber-500 mt-1">
                {Rupee} {payment.outstanding_amount?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </h3>
            </div>
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-amber-50 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400">
              <Clock className="w-5 h-5" />
            </div>
          </CardContent>
        </Card>

        {/* SUCCESS RATE */}
        <Card className="shadow-xs border-slate-200 dark:border-slate-800">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                SUCCESS RATE
              </p>
              <h3 className="text-xl font-extrabold text-emerald-600 dark:text-emerald-400 mt-1">
                {payment.payment_success_rate}%
              </h3>
            </div>
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </CardContent>
        </Card>

        {/* FAILED PAYMENTS */}
        <Card className="shadow-xs border-slate-200 dark:border-slate-800">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                FAILED PAYMENTS
              </p>
              <h3 className="text-xl font-extrabold text-rose-600 dark:text-rose-400 mt-1">
                {payment.failed_payments}
              </h3>
            </div>
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-rose-50 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </CardContent>
        </Card>

        {/* AVG PAYMENT DELAY */}
        <Card className="shadow-xs border-slate-200 dark:border-slate-800">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                AVG PAYMENT DELAY
              </p>
              <h3 className="text-xl font-extrabold text-purple-600 dark:text-purple-400 mt-1">
                {payment.avg_payment_delay_days} Days
              </h3>
            </div>
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-purple-50 text-purple-600 dark:bg-purple-950/40 dark:text-purple-400">
              <Calendar className="w-5 h-5" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════
          ROW 2: REVENUE FORECAST TRENDS & PLAN ADOPTION DETAILS
      ═══════════════════════════════════════════════════════════════════ */}
      <div className="grid gap-6 lg:grid-cols-12">
        {/* REVENUE FORECAST CHART (lg:col-span-7) */}
        <Card className="lg:col-span-7 shadow-xs border-slate-200 dark:border-slate-800">
          <CardHeader className="flex flex-row items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <CardTitle className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Revenue Forecast Trends
            </CardTitle>
            <div className="flex items-center gap-2">
              <div className="flex border border-slate-200 dark:border-slate-700 rounded-md overflow-hidden text-xs">
                <button
                  type="button"
                  onClick={() => setViewType('mrr')}
                  className={`px-3 py-1 font-semibold transition-colors cursor-pointer ${
                    viewType === 'mrr'
                      ? 'bg-[#147659] text-white'
                      : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
                  }`}
                >
                  MRR
                </button>
                <button
                  type="button"
                  onClick={() => setViewType('arr')}
                  className={`px-3 py-1 font-semibold transition-colors cursor-pointer border-l border-slate-200 dark:border-slate-700 ${
                    viewType === 'arr'
                      ? 'bg-[#1c84ee] text-white'
                      : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
                  }`}
                >
                  ARR
                </button>
              </div>

              <button
                type="button"
                onClick={() => refetchRevenue()}
                title="Refresh Revenue Data"
                className="p-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <RefreshCw className="h-3.5 w-3.5" />
              </button>
            </div>
          </CardHeader>

          <CardContent className="pt-4 space-y-4">
            {/* Current MRR / ARR KPI Boxes */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-xl text-center">
                <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">CURRENT MRR</p>
                <h4 className="text-xl font-bold text-[#147659] mt-0.5">
                  {Rupee} {currentMrr.toLocaleString()}
                </h4>
              </div>

              <div className="p-3 bg-blue-500/5 border border-blue-500/20 rounded-xl text-center">
                <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">CURRENT ARR</p>
                <h4 className="text-xl font-bold text-[#1c84ee] mt-0.5">
                  {Rupee} {currentArr.toLocaleString()}
                </h4>
              </div>
            </div>

            {/* Smooth Area Chart */}
            <div className="h-[280px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartPoints} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
                  <defs>
                    <linearGradient id="revGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={viewType === 'mrr' ? '#147659' : '#1c84ee'} stopOpacity={0.4} />
                      <stop offset="95%" stopColor={viewType === 'mrr' ? '#147659' : '#1c84ee'} stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="5 5" vertical={false} stroke="#f1f1f1" />
                  <XAxis
                    dataKey="formattedMonth"
                    tickLine={false}
                    axisLine={false}
                    tick={{ fontSize: 11, fill: '#96a0b5', fontWeight: 500 }}
                  />
                  <YAxis
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(val) => `${Rupee}${val >= 100000 ? (val / 100000).toFixed(1) + 'L' : val.toLocaleString()}`}
                    tick={{ fontSize: 11, fill: '#96a0b5', fontWeight: 500 }}
                  />
                  <Tooltip
                    formatter={(val: any) => [
                      `${Rupee} ${Number(val).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
                      viewType === 'mrr' ? 'Monthly Recurring Revenue' : 'Annual Recurring Revenue',
                    ]}
                    contentStyle={{
                      backgroundColor: '#ffffff',
                      borderRadius: '8px',
                      border: '1px solid #f0f0f0',
                      boxShadow: '0 4px 15px rgba(0,0,0,0.06)',
                      fontSize: '12px',
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="amount"
                    stroke={viewType === 'mrr' ? '#147659' : '#1c84ee'}
                    strokeWidth={3}
                    fillOpacity={1}
                    fill="url(#revGradient)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* PLAN ADOPTION, RENEWALS & CANCELLATIONS (lg:col-span-5) */}
        <Card className="lg:col-span-5 shadow-xs border-slate-200 dark:border-slate-800 flex flex-col">
          <CardHeader className="p-0 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between px-4 pt-3 pb-2">
              <div className="flex gap-2">
                {(['adoption', 'renewals', 'cancellations'] as const).map((tab) => (
                  <button
                    key={tab}
                    type="button"
                    onClick={() => setActiveAdoptionTab(tab)}
                    className={`text-xs font-bold pb-2 px-1 capitalize transition-colors border-b-2 cursor-pointer ${
                      activeAdoptionTab === tab
                        ? 'border-[#147659] text-[#147659]'
                        : 'border-transparent text-slate-400 hover:text-slate-700'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={() => {
                  refetchAdoption();
                  refetchRenewal();
                  refetchCancellation();
                }}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-md cursor-pointer"
              >
                <RefreshCw className="h-3.5 w-3.5" />
              </button>
            </div>
          </CardHeader>

          <CardContent className="p-4 flex-1 flex flex-col justify-between">
            {activeAdoptionTab === 'adoption' && (
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-900 rounded-lg">
                  <div>
                    <span className="text-[11px] font-semibold text-slate-400 uppercase">Total Active Subscriptions</span>
                    <h4 className="text-xl font-bold text-slate-900 dark:text-slate-100 mt-0.5">
                      {adoption.total_active_subscriptions.toLocaleString()}
                    </h4>
                  </div>
                  <div className="text-right">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase">Trial Conversion</span>
                    <h4 className="text-xl font-bold text-emerald-600 mt-0.5">
                      {adoption.trial_conversion_rate}%
                    </h4>
                  </div>
                </div>

                <div className="space-y-2.5">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">Plan Breakdown</span>
                  {(adoption.plan_breakdown || []).map((p, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="font-medium text-slate-600 dark:text-slate-300">{p.plan_name}</span>
                        <span className="font-semibold">{p.count} ({p.percentage}%)</span>
                      </div>
                      <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                        <div className="h-full bg-[#147659] rounded-full transition-all" style={{ width: `${p.percentage}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeAdoptionTab === 'renewals' && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 bg-emerald-500/5 rounded-lg border border-emerald-500/20 text-center">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase">Renewal Rate</span>
                    <h4 className="text-2xl font-bold text-emerald-600 mt-0.5">{renewal.renewal_rate}%</h4>
                  </div>
                  <div className="p-3 bg-blue-500/5 rounded-lg border border-blue-500/20 text-center">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase">Upcoming Renewals</span>
                    <h4 className="text-2xl font-bold text-blue-600 mt-0.5">{renewal.upcoming_renewals_count}</h4>
                  </div>
                </div>

                <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-lg space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-500">Successfully Renewed Accounts</span>
                    <span className="font-bold text-slate-900 dark:text-slate-100">{renewal.renewed_count}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-500">Auto-Renewal Gateway Status</span>
                    <span className="font-bold text-emerald-600">Active (100% SLA)</span>
                  </div>
                </div>
              </div>
            )}

            {activeAdoptionTab === 'cancellations' && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 bg-rose-500/5 rounded-lg border border-rose-500/20 text-center">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase">Total Cancellations</span>
                    <h4 className="text-2xl font-bold text-rose-600 mt-0.5">{cancellation.total_cancellations}</h4>
                  </div>
                  <div className="p-3 bg-amber-500/5 rounded-lg border border-amber-500/20 text-center">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase">Churn Rate</span>
                    <h4 className="text-2xl font-bold text-amber-600 mt-0.5">{cancellation.churn_rate}%</h4>
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">Cancellation Primary Reasons</span>
                  {(cancellation.reasons || []).map((r, i) => (
                    <div key={i} className="flex justify-between text-xs py-1 border-b border-slate-100 dark:border-slate-800 last:border-0">
                      <span className="text-slate-600 dark:text-slate-400">{r.reason}</span>
                      <span className="font-bold text-slate-900 dark:text-slate-200">{r.count}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════
          ROW 3: REQUEST OPERATIONS, TOP PLANS, RENEWAL FUNNEL, HEALTH
      ═══════════════════════════════════════════════════════════════════ */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* REQUEST DISTRIBUTION CHART */}
        <Card className="shadow-xs border-slate-200 dark:border-slate-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Request Operations & Defect Distribution
            </CardTitle>
            <button
              type="button"
              onClick={() => refetchRequest()}
              className="p-1 text-slate-400 hover:text-slate-700 rounded-md cursor-pointer"
            >
              <RefreshCw className="h-3.5 w-3.5" />
            </button>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="h-[200px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={requestDistributionItems}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {requestDistributionItems.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={REQUEST_COLORS[index % REQUEST_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#ffffff',
                      borderRadius: '8px',
                      border: '1px solid #f0f0f0',
                      fontSize: '12px',
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="space-y-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-600 dark:text-slate-400">Invoice Generated vs Pending</span>
                  <span className="font-semibold">{invoicePercentage}% ({request?.invoice_generated_requests}/{invoiceTotal})</span>
                </div>
                <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-[#3686ff] rounded-full transition-all" style={{ width: `${invoicePercentage}%` }} />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-600 dark:text-slate-400">Instances Created vs Pending</span>
                  <span className="font-semibold">{instancePercentage}% ({request?.instance_created}/{instanceTotal})</span>
                </div>
                <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-[#147659] rounded-full transition-all" style={{ width: `${instancePercentage}%` }} />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* TOP PLANS DISTRIBUTION */}
        <Card className="shadow-xs border-slate-200 dark:border-slate-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Top Plans Distribution
            </CardTitle>
            <button
              type="button"
              onClick={() => refetchPlans()}
              className="p-1 text-slate-400 hover:text-slate-700 rounded-md cursor-pointer"
            >
              <RefreshCw className="h-3.5 w-3.5" />
            </button>
          </CardHeader>
          <CardContent>
            <div className="h-[200px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={topPlansItems}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={85}
                    paddingAngle={3}
                    dataKey="count"
                  >
                    {topPlansItems.map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={PLAN_COLORS[index % PLAN_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#ffffff',
                      borderRadius: '8px',
                      border: '1px solid #f0f0f0',
                      fontSize: '12px',
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-xs">
              <span className="text-slate-500">Total Subscriptions across fleet</span>
              <span className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                {totalPlanSubscriptions.toLocaleString()}
              </span>
            </div>
          </CardContent>
        </Card>

        {/* RENEWAL FUNNEL VISUAL */}
        <Card className="shadow-xs border-slate-200 dark:border-slate-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Renewal Funnel
            </CardTitle>
            <button
              type="button"
              onClick={() => refetchFunnel()}
              className="p-1 text-slate-400 hover:text-slate-700 rounded-md cursor-pointer"
            >
              <RefreshCw className="h-3.5 w-3.5" />
            </button>
          </CardHeader>
          <CardContent className="space-y-3 pt-2">
            {[
              { label: 'Due This Month', value: funnel.due_this_month, width: '100%', bg: 'bg-[#147659]', text: 'text-[#147659]' },
              { label: 'Invoice Generated', value: funnel.invoice_generated, width: '82%', bg: 'bg-[#3686ff]', text: 'text-[#3686ff]' },
              { label: 'Payment Received', value: funnel.payment_received, width: '64%', bg: 'bg-[#2bb673]', text: 'text-[#2bb673]' },
              { label: 'Payment Failed', value: funnel.failed, width: '46%', bg: 'bg-[#ff6b77]', text: 'text-[#ff6b77]' },
            ].map((step, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className={`font-semibold ${step.text}`}>{step.label}</span>
                  <span className="font-bold text-slate-900 dark:text-slate-100">{step.value}</span>
                </div>
                <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full ${step.bg}`} style={{ width: step.width }} />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* SYSTEM HEALTH & ACTIVITY CARD (MATCHING superadminfe) */}
        <Card className="shadow-xs border-slate-200 dark:border-slate-800 flex flex-col justify-between">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-bold text-[#147659]">
              System Health & Activity
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              This dashboard reflects real-time metrics across billing cycles, subscription statuses,
              plan conversions, and request queues. Ensure all pending cancellation requests and pending
              instance deployments are processed timely to maintain high customer satisfaction.
            </p>

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-4">
              <div>
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  TOTAL SYSTEM REQUESTS
                </span>
                <span className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 mt-0.5 block">
                  {request.total_requests}
                </span>
              </div>

              <div>
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  ACTIVE SUBSCRIPTIONS
                </span>
                <span className="text-2xl font-extrabold text-[#147659] mt-0.5 block">
                  {adoption.total_active_subscriptions.toLocaleString()}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
