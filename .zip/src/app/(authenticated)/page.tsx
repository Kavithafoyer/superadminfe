'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  Users,
  TrendingUp,
  Activity,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  RefreshCw,
  Server,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  FileText,
  DollarSign,
  PieChart as PieChartIcon,
  ChevronRight,
  Building2,
  Calendar,
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useStore } from '@/store/useStore';
import { ReusableTable, ColumnConfig } from '@/components/ui/ReusableTable';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import {
  useGetSubscriptionAnalyticsQuery,
  useGetSubscriptionInsightsQuery,
  useGetUsageAnalyticsQuery,
  useGetInstanceAnalyticsQuery,
  MOCK_SUBSCRIPTION_ANALYTICS,
  MOCK_SUBSCRIPTION_INSIGHTS,
  MOCK_USAGE_ANALYTICS,
  MOCK_INSTANCE_ANALYTICS,
} from '@/service/api/superAdminService';

interface TenantRecord {
  id: string;
  name: string;
  subdomain: string;
  plan: string;
  status: 'Active' | 'Trial' | 'Pending' | 'Suspended';
  seats: number;
  renewalDate: string;
  mrr: string;
}

const RECENT_TENANTS: TenantRecord[] = [
  { id: 'TNT-101', name: 'Apex Global Technologies', subdomain: 'apexglobal.crmfarm.app', plan: 'Enterprise Platinum', status: 'Active', seats: 250, renewalDate: '2027-01-15', mrr: '$4,250' },
  { id: 'TNT-102', name: 'CloudTech Solutions Ltd', subdomain: 'cloudtech.crmfarm.app', plan: 'Business Pro', status: 'Active', seats: 120, renewalDate: '2026-12-10', mrr: '$1,950' },
  { id: 'TNT-103', name: 'Nexus Logistics Corp', subdomain: 'nexus.crmfarm.app', plan: 'Enterprise Platinum', status: 'Active', seats: 400, renewalDate: '2027-03-22', mrr: '$6,800' },
  { id: 'TNT-104', name: 'Starlight Retail Group', subdomain: 'starlight.crmfarm.app', plan: 'Growth Starter', status: 'Trial', seats: 45, renewalDate: '2026-11-30', mrr: '$490' },
  { id: 'TNT-105', name: 'Vanguard FinTech', subdomain: 'vanguard.crmfarm.app', plan: 'Business Pro', status: 'Active', seats: 180, renewalDate: '2027-02-18', mrr: '$2,750' },
  { id: 'TNT-106', name: 'Helios Healthcare', subdomain: 'helios.crmfarm.app', plan: 'Custom Enterprise', status: 'Pending', seats: 500, renewalDate: '2027-05-01', mrr: '$8,500' },
];

const DONUT_COLORS = ['#0565FD', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899'];

export default function SuperAdminDashboardPage() {
  const router = useRouter();
  const { user, primaryColor } = useStore();

  // RTK Query API Hooks
  const {
    data: subAnalyticsData,
    isLoading: loadingSub,
    isError: errorSub,
    refetch: refetchSub,
  } = useGetSubscriptionAnalyticsQuery();

  const {
    data: insightsData,
    isLoading: loadingInsights,
    isError: errorInsights,
    refetch: refetchInsights,
  } = useGetSubscriptionInsightsQuery();

  const {
    data: usageData,
    isLoading: loadingUsage,
    isError: errorUsage,
    refetch: refetchUsage,
  } = useGetUsageAnalyticsQuery();

  const {
    data: instanceData,
    isLoading: loadingInstance,
    isError: errorInstance,
    refetch: refetchInstance,
  } = useGetInstanceAnalyticsQuery();

  const subAnalytics = subAnalyticsData || MOCK_SUBSCRIPTION_ANALYTICS;
  const insights = insightsData || MOCK_SUBSCRIPTION_INSIGHTS;
  const usage = usageData || MOCK_USAGE_ANALYTICS;
  const instance = instanceData || MOCK_INSTANCE_ANALYTICS;

  const handleRefetchAll = () => {
    refetchSub();
    refetchInsights();
    refetchUsage();
    refetchInstance();
  };

  const donutData = (insights?.churn_by_product || []).map((item) => ({
    name: item.product,
    value: item.total,
  }));

  const tenantColumns: ColumnConfig<TenantRecord>[] = [
    {
      key: 'name',
      header: 'Tenant / Organization',
      sortable: true,
      render: (row) => (
        <div className="flex flex-col">
          <span className="font-semibold text-slate-900 dark:text-slate-100">{row.name}</span>
          <span className="text-xs text-muted-foreground font-mono">{row.subdomain}</span>
        </div>
      ),
    },
    {
      key: 'plan',
      header: 'Assigned Plan',
      sortable: true,
      render: (row) => (
        <Badge variant="secondary" className="font-medium text-xs">
          {row.plan}
        </Badge>
      ),
    },
    {
      key: 'seats',
      header: 'User Quota',
      sortable: true,
      render: (row) => <span className="text-xs font-semibold">{row.seats} seats</span>,
    },
    {
      key: 'status',
      header: 'Status',
      sortable: true,
      render: (row) => {
        const variants: Record<string, string> = {
          Active: 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800',
          Trial: 'bg-blue-500/15 text-blue-700 dark:text-blue-400 border-blue-200 dark:border-blue-800',
          Pending: 'bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-800',
          Suspended: 'bg-rose-500/15 text-rose-700 dark:text-rose-400 border-rose-200 dark:border-rose-800',
        };
        return (
          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border ${variants[row.status]}`}>
            {row.status}
          </span>
        );
      },
    },
    {
      key: 'renewalDate',
      header: 'Renewal Date',
      sortable: true,
      render: (row) => <span className="text-xs text-slate-600 dark:text-slate-400">{row.renewalDate}</span>,
    },
    {
      key: 'mrr',
      header: 'Monthly MRR',
      sortable: true,
      render: (row) => <span className="font-mono font-bold text-xs text-slate-900 dark:text-slate-100">{row.mrr}</span>,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100">
              SuperAdmin Overview
            </h1>
            <Badge variant="outline" className="text-xs font-semibold border-primary/30 text-primary bg-primary/5">
              Live Cloud Fleet
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            Real-time multi-tenant telemetry, subscription analytics, and cloud instance health.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefetchAll}
            className="gap-2 cursor-pointer text-xs font-semibold"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Sync Metrics
          </Button>
          <Button
            size="sm"
            onClick={() => router.push('/forms?tab=plan')}
            className="gap-2 cursor-pointer text-xs font-semibold"
          >
            <Plus className="h-3.5 w-3.5" />
            Create Plan
          </Button>
          <Button
            size="sm"
            variant="secondary"
            onClick={() => router.push('/forms?tab=subscription')}
            className="gap-2 cursor-pointer text-xs font-semibold"
          >
            <Plus className="h-3.5 w-3.5" />
            New Subscription
          </Button>
        </div>
      </div>

      {/* KPI Highlight Row (Matching superadminfe SubscriptionAnalytics) */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="shadow-xs border-slate-200 dark:border-slate-800 bg-linear-to-br from-white to-blue-50/20 dark:from-slate-900 dark:to-slate-900/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
              Active Subscriptions
            </CardTitle>
            <div className="h-9 w-9 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Layers className="h-5 w-5" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100">
              {subAnalytics.active.toLocaleString()}
            </div>
            <div className="flex items-center gap-1.5 mt-1.5">
              <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 flex items-center">
                <ArrowUpRight className="h-3.5 w-3.5 mr-0.5" />
                +14.8%
              </span>
              <span className="text-xs text-muted-foreground">vs last quarter</span>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-xs border-slate-200 dark:border-slate-800 bg-linear-to-br from-white to-cyan-50/20 dark:from-slate-900 dark:to-slate-900/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
              Trial Subscriptions
            </CardTitle>
            <div className="h-9 w-9 rounded-xl bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 flex items-center justify-center">
              <Activity className="h-5 w-5" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100">
              {subAnalytics.trial.toLocaleString()}
            </div>
            <div className="flex items-center gap-1.5 mt-1.5">
              <span className="text-xs font-semibold text-cyan-600 dark:text-cyan-400">
                14-day trials
              </span>
              <span className="text-xs text-muted-foreground">• 62% conversion avg</span>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-xs border-slate-200 dark:border-slate-800 bg-linear-to-br from-white to-amber-50/20 dark:from-slate-900 dark:to-slate-900/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
              Expired / Churned
            </CardTitle>
            <div className="h-9 w-9 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <AlertCircle className="h-5 w-5" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100">
              {subAnalytics.expired.toLocaleString()}
            </div>
            <div className="flex items-center gap-1.5 mt-1.5">
              <span className="text-xs font-semibold text-rose-500 flex items-center">
                <ArrowDownRight className="h-3.5 w-3.5 mr-0.5" />
                -2.1%
              </span>
              <span className="text-xs text-muted-foreground">churn rate</span>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-xs border-slate-200 dark:border-slate-800 bg-linear-to-br from-white to-emerald-50/20 dark:from-slate-900 dark:to-slate-900/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
              Renewal Rate
            </CardTitle>
            <div className="h-9 w-9 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <CheckCircle2 className="h-5 w-5" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100">
              {subAnalytics.renewal_rate}%
            </div>
            <div className="flex items-center gap-1.5 mt-1.5">
              <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                High Retention
              </span>
              <span className="text-xs text-muted-foreground">• Top tier benchmark</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Analytics Grid: Usage Analytics & Subscription Insights */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Usage Analytics Area Chart */}
        <Card className="lg:col-span-2 shadow-xs border-slate-200 dark:border-slate-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base font-bold text-slate-900 dark:text-slate-100">
                Usage Analytics (Daily Active Users)
              </CardTitle>
              <CardDescription className="text-xs">
                Aggregated activity volume across all active tenant deployments
              </CardDescription>
            </div>
            <Badge variant="secondary" className="text-xs font-semibold">
              Weekly Activity
            </Badge>
          </CardHeader>
          <CardContent className="pt-2">
            <div className="h-[280px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={usage.dau_trend} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="usageGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0565FD" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#0565FD" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" opacity={0.6} />
                  <XAxis dataKey="date" tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#64748b' }} />
                  <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#64748b' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(255, 255, 255, 0.95)',
                      borderRadius: '8px',
                      border: '1px solid #e2e8f0',
                      boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
                      fontSize: '12px',
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="active_users"
                    name="Active Users"
                    stroke="#0565FD"
                    strokeWidth={2.5}
                    fillOpacity={1}
                    fill="url(#usageGradient)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4 border-t border-slate-100 dark:border-slate-800 text-xs">
              <div>
                <span className="text-muted-foreground block">Total Cloud Storage</span>
                <span className="font-bold text-slate-800 dark:text-slate-200 text-sm">
                  {usage.total_storage_gb?.toLocaleString() || '4,820'} GB
                </span>
              </div>
              <div>
                <span className="text-muted-foreground block">API Calls Today</span>
                <span className="font-bold text-slate-800 dark:text-slate-200 text-sm">
                  {usage.api_calls_today?.toLocaleString() || '184,500'}
                </span>
              </div>
              <div className="col-span-2 sm:col-span-1">
                <span className="text-muted-foreground block">System Status</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400 text-sm flex items-center gap-1">
                  <CheckCircle2 className="h-3.5 w-3.5" /> All Services Operational
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Subscription Insights Donut Chart */}
        <Card className="shadow-xs border-slate-200 dark:border-slate-800 flex flex-col">
          <CardHeader>
            <CardTitle className="text-base font-bold text-slate-900 dark:text-slate-100">
              Subscription Insights
            </CardTitle>
            <CardDescription className="text-xs">
              Distribution and churn analysis by product tier
            </CardDescription>
          </CardHeader>
          <CardContent className="flex-1 flex flex-col justify-center">
            <div className="h-[210px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={donutData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {donutData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={DONUT_COLORS[index % DONUT_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(255, 255, 255, 0.95)',
                      borderRadius: '8px',
                      border: '1px solid #e2e8f0',
                      boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
                      fontSize: '12px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              {donutData.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: DONUT_COLORS[idx % DONUT_COLORS.length] }}
                    />
                    <span className="text-slate-600 dark:text-slate-300 font-medium">{item.name}</span>
                  </div>
                  <span className="font-bold text-slate-900 dark:text-slate-100">{item.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Instance Analytics & Subscription Growth Row */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Instance Analytics */}
        <Card className="shadow-xs border-slate-200 dark:border-slate-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base font-bold text-slate-900 dark:text-slate-100">
                Instance Analytics & Telemetry
              </CardTitle>
              <CardDescription className="text-xs">
                Deployment count, server health, and CPU/memory load
              </CardDescription>
            </div>
            <Badge variant="outline" className="text-xs font-semibold text-emerald-600 border-emerald-300">
              {instance.healthy_count}/{instance.total_instances} Healthy
            </Badge>
          </CardHeader>
          <CardContent>
            <div className="h-[220px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={instance.growth} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" opacity={0.6} />
                  <XAxis dataKey="period" tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#64748b' }} />
                  <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#64748b' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(255, 255, 255, 0.95)',
                      borderRadius: '8px',
                      border: '1px solid #e2e8f0',
                      fontSize: '12px',
                    }}
                  />
                  <Bar dataKey="total" name="Total Instances" fill="#0565FD" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="active" name="Active Pods" fill="#10B981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-4 mt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
              <div className="bg-slate-50 dark:bg-slate-900 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
                <span className="text-muted-foreground block text-[11px]">Fleet CPU Utilization</span>
                <span className="text-base font-bold text-slate-800 dark:text-slate-200">
                  {instance.avg_cpu_percent}%
                </span>
                <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full mt-1.5 overflow-hidden">
                  <div className="bg-blue-600 h-full rounded-full" style={{ width: `${instance.avg_cpu_percent}%` }} />
                </div>
              </div>

              <div className="bg-slate-50 dark:bg-slate-900 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
                <span className="text-muted-foreground block text-[11px]">Fleet Memory Utilization</span>
                <span className="text-base font-bold text-slate-800 dark:text-slate-200">
                  {instance.avg_memory_percent}%
                </span>
                <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full mt-1.5 overflow-hidden">
                  <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${instance.avg_memory_percent}%` }} />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Subscription Growth Chart */}
        <Card className="shadow-xs border-slate-200 dark:border-slate-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base font-bold text-slate-900 dark:text-slate-100">
                Subscription Growth & Revenue Momentum
              </CardTitle>
              <CardDescription className="text-xs">
                Expansion trajectory vs target revenue metrics
              </CardDescription>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => router.push('/analytics-dashboard')}
              className="text-xs text-primary gap-1 font-semibold"
            >
              Full Analytics <ChevronRight className="h-3.5 w-3.5" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="h-[220px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={[
                    { month: 'Jun', subs: 2800, arr: 1100 },
                    { month: 'Jul', subs: 3050, arr: 1220 },
                    { month: 'Aug', subs: 3280, arr: 1310 },
                    { month: 'Sep', subs: 3490, arr: 1390 },
                    { month: 'Oct', subs: 3710, arr: 1440 },
                    { month: 'Nov', subs: 3840, arr: 1494 },
                  ]}
                  margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" opacity={0.6} />
                  <XAxis dataKey="month" tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#64748b' }} />
                  <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#64748b' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(255, 255, 255, 0.95)',
                      borderRadius: '8px',
                      border: '1px solid #e2e8f0',
                      fontSize: '12px',
                    }}
                  />
                  <Line type="monotone" dataKey="subs" name="Total Subscriptions" stroke="#0565FD" strokeWidth={3} dot={{ r: 4 }} />
                  <Line type="monotone" dataKey="arr" name="ARR ($k)" stroke="#10B981" strokeWidth={2} strokeDasharray="4 4" dot={{ r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-4 mt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
              <div className="flex items-center gap-2.5">
                <div className="h-8 w-8 rounded-lg bg-emerald-500/10 text-emerald-600 flex items-center justify-center shrink-0">
                  <DollarSign className="h-4 w-4" />
                </div>
                <div>
                  <span className="text-muted-foreground block text-[11px]">Monthly Recurring Revenue</span>
                  <span className="font-bold text-slate-900 dark:text-slate-100 text-sm">$124,500 MRR</span>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <div className="h-8 w-8 rounded-lg bg-blue-500/10 text-blue-600 flex items-center justify-center shrink-0">
                  <TrendingUp className="h-4 w-4" />
                </div>
                <div>
                  <span className="text-muted-foreground block text-[11px]">Annual Run Rate</span>
                  <span className="font-bold text-slate-900 dark:text-slate-100 text-sm">$1.49M ARR</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Tenants Table */}
      <Card className="shadow-xs border-slate-200 dark:border-slate-800">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-base font-bold text-slate-900 dark:text-slate-100">
              Recent Tenant Deployments
            </CardTitle>
            <CardDescription className="text-xs">
              Latest provisioned tenant workspaces, assigned plans, and subscription renewal timelines
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => router.push('/tables')}
              className="text-xs font-semibold"
            >
              View All Records
            </Button>
            <Button
              size="sm"
              onClick={() => router.push('/forms?tab=customer')}
              className="gap-1.5 text-xs font-semibold"
            >
              <Plus className="h-3.5 w-3.5" />
              Onboard Tenant
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <ReusableTable
            data={RECENT_TENANTS}
            columns={tenantColumns}
            searchable={true}
            searchPlaceholder="Search tenants, subdomains, plans..."
            pageSize={6}
          />
        </CardContent>
      </Card>
    </div>
  );
}
