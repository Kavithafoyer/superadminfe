'use client';

import React, { useState } from 'react';
import { Settings as SettingsIcon, Sun, Moon, Monitor, Palette, Bell, Shield, Check, Globe } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { useStore } from '@/store/useStore';
import { toast } from 'sonner';

export default function SettingsPage() {
  const { mode, setMode, primaryColor, setPrimaryColor, user, updateUserProfile } = useStore();
  const [workspaceName, setWorkspaceName] = useState(user.workspace || 'Main Organization');
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [compactDensity, setCompactDensity] = useState(false);

  const colors = [
    { name: 'Blue', value: '#0565FD' },
    { name: 'Indigo', value: '#6366f1' },
    { name: 'Violet', value: '#8b5cf6' },
    { name: 'Emerald', value: '#10b981' },
    { name: 'Orange', value: '#f97316' },
    { name: 'Rose', value: '#f43f5e' },
    { name: 'Zinc', value: '#71717a' },
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile({ workspace: workspaceName });
    toast.success('Settings saved successfully');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
          <SettingsIcon className="h-6 w-6 text-primary" />
          Settings
        </h1>
        <p className="text-sm text-muted-foreground mt-0.5">
          Manage system preferences, appearance, and workspace configuration.
        </p>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Appearance Settings */}
        <Card className="shadow-xs border-slate-200 dark:border-slate-800">
          <CardHeader>
            <CardTitle className="text-base font-bold flex items-center gap-2">
              <Palette className="h-4 w-4 text-primary" />
              Appearance & Theme
            </CardTitle>
            <CardDescription>
              Customize how the template looks across your browser session.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Color Mode */}
            <div>
              <Label className="text-xs font-semibold block mb-2.5">Color Mode</Label>
              <div className="grid grid-cols-3 gap-3 max-w-sm">
                {[
                  { id: 'light', icon: Sun, label: 'Light' },
                  { id: 'dark', icon: Moon, label: 'Dark' },
                  { id: 'system', icon: Monitor, label: 'System' },
                ].map((item) => {
                  const Icon = item.icon;
                  const active = mode === item.id;
                  return (
                    <button
                      type="button"
                      key={item.id}
                      onClick={() => setMode(item.id as any)}
                      className={`flex flex-col items-center justify-center p-3 rounded-xl border text-xs font-semibold gap-1.5 transition-all cursor-pointer ${
                        active
                          ? 'bg-primary/10 border-primary text-primary'
                          : 'bg-card border-slate-200 dark:border-slate-800 text-muted-foreground hover:bg-slate-50 dark:hover:bg-slate-900'
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                      {item.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Accent Color */}
            <div>
              <Label className="text-xs font-semibold block mb-2.5">Primary Accent Color</Label>
              <div className="flex flex-wrap items-center gap-3">
                {colors.map((c) => (
                  <button
                    type="button"
                    key={c.value}
                    onClick={() => setPrimaryColor(c.value)}
                    className="h-8 w-8 rounded-full border flex items-center justify-center transition-transform hover:scale-110 cursor-pointer shadow-xs"
                    style={{ backgroundColor: c.value }}
                    title={c.name}
                  >
                    {primaryColor === c.value && <Check className="h-4 w-4 text-white" />}
                  </button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Workspace Configuration */}
        <Card className="shadow-xs border-slate-200 dark:border-slate-800">
          <CardHeader>
            <CardTitle className="text-base font-bold flex items-center gap-2">
              <Globe className="h-4 w-4 text-primary" />
              Workspace Details
            </CardTitle>
            <CardDescription>
              Configure the organization or project workspace title.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="workspaceName" className="text-xs font-semibold">
                Workspace / Project Name
              </Label>
              <Input
                id="workspaceName"
                value={workspaceName}
                onChange={(e) => setWorkspaceName(e.target.value)}
              />
            </div>

            <div className="pt-2 space-y-3">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="emailAlerts"
                  checked={emailAlerts}
                  onCheckedChange={(checked) => setEmailAlerts(Boolean(checked))}
                />
                <Label htmlFor="emailAlerts" className="text-xs font-medium cursor-pointer">
                  Enable critical system alert emails
                </Label>
              </div>
            </div>
          </CardContent>

          <CardFooter className="flex justify-end border-t py-4 px-6 bg-slate-50/50 dark:bg-slate-900/30">
            <Button type="submit" size="sm" className="text-xs font-semibold">
              Save Changes
            </Button>
          </CardFooter>
        </Card>
      </form>
    </div>
  );
}
