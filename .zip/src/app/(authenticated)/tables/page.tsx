'use client';

import React, { useState } from 'react';
import {
  Table as TableIcon,
  Plus,
  Trash2,
  Edit,
  Eye,
  Download,
  Filter,
  CheckCircle2,
  Clock,
  AlertCircle,
  MoreHorizontal,
  RefreshCw,
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ReusableTable, ColumnConfig } from '@/components/ui/ReusableTable';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';

interface UserRecord {
  id: string;
  name: string;
  email: string;
  role: string;
  department: string;
  status: 'Active' | 'Pending' | 'Inactive';
  lastActive: string;
  joinDate: string;
}

const INITIAL_RECORDS: UserRecord[] = [
  { id: 'USR-101', name: 'Liam Davies', email: 'liam.davies@example.com', role: 'DevOps Lead', department: 'Infrastructure', status: 'Active', lastActive: '2 mins ago', joinDate: '2024-03-12' },
  { id: 'USR-102', name: 'Sophia Chen', email: 'sophia.chen@example.com', role: 'Product Manager', department: 'Product', status: 'Active', lastActive: '10 mins ago', joinDate: '2023-11-04' },
  { id: 'USR-103', name: 'Elena Rostova', email: 'elena.rostova@example.com', role: 'Lead Architect', department: 'Engineering', status: 'Active', lastActive: '1 hour ago', joinDate: '2022-08-19' },
  { id: 'USR-104', name: 'Alexander Wright', email: 'alex.wright@example.com', role: 'Senior Frontend Dev', department: 'Engineering', status: 'Active', lastActive: '3 hours ago', joinDate: '2023-01-15' },
  { id: 'USR-105', name: 'Chloe Kim', email: 'chloe.kim@example.com', role: 'UI/UX Designer', department: 'Design', status: 'Pending', lastActive: '1 day ago', joinDate: '2024-06-20' },
  { id: 'USR-106', name: 'Marcus Brody', email: 'marcus.brody@example.com', role: 'Backend Engineer', department: 'Engineering', status: 'Active', lastActive: '4 hours ago', joinDate: '2023-09-01' },
  { id: 'USR-107', name: 'Amara Okafor', email: 'amara.okafor@example.com', role: 'Data Scientist', department: 'Analytics', status: 'Active', lastActive: 'Just now', joinDate: '2024-01-10' },
  { id: 'USR-108', name: 'Noah Miller', email: 'noah.miller@example.com', role: 'Security Analyst', department: 'Security', status: 'Inactive', lastActive: '2 weeks ago', joinDate: '2022-04-18' },
  { id: 'USR-109', name: 'Olivia Taylor', email: 'olivia.taylor@example.com', role: 'Content Strategist', department: 'Marketing', status: 'Active', lastActive: '5 hours ago', joinDate: '2023-07-22' },
  { id: 'USR-110', name: 'Ethan Garcia', email: 'ethan.garcia@example.com', role: 'QA Automation', department: 'Engineering', status: 'Pending', lastActive: '3 days ago', joinDate: '2024-05-14' },
  { id: 'USR-111', name: 'Isabella Rossi', email: 'isabella.rossi@example.com', role: 'Finance Specialist', department: 'Finance', status: 'Active', lastActive: '2 days ago', joinDate: '2023-02-28' },
  { id: 'USR-112', name: 'William Brown', email: 'william.brown@example.com', role: 'HR Coordinator', department: 'Operations', status: 'Active', lastActive: '1 day ago', joinDate: '2024-02-01' },
];

export default function TablesPage() {
  const [data, setData] = useState<UserRecord[]>(INITIAL_RECORDS);
  const [selectedRows, setSelectedRows] = useState<UserRecord[]>([]);

  const handleDelete = (id: string) => {
    setData((prev) => prev.filter((item) => item.id !== id));
    toast.success(`Record ${id} removed successfully`);
  };

  const handleBulkDelete = () => {
    if (selectedRows.length === 0) return;
    const ids = new Set(selectedRows.map((r) => r.id));
    setData((prev) => prev.filter((r) => !ids.has(r.id)));
    setSelectedRows([]);
    toast.success(`Removed ${selectedRows.length} selected records`);
  };

  const columns: ColumnConfig<UserRecord>[] = [
    {
      key: 'id',
      header: 'ID',
      sortable: true,
      width: '100px',
      render: (row) => <span className="font-mono text-xs font-semibold">{row.id}</span>,
    },
    {
      key: 'name',
      header: 'Name & Email',
      sortable: true,
      render: (row) => (
        <div className="flex flex-col">
          <span className="font-semibold text-slate-900 dark:text-slate-100">{row.name}</span>
          <span className="text-xs text-muted-foreground">{row.email}</span>
        </div>
      ),
    },
    {
      key: 'role',
      header: 'Designation',
      sortable: true,
      render: (row) => <span className="text-xs font-medium">{row.role}</span>,
    },
    {
      key: 'department',
      header: 'Department',
      sortable: true,
      render: (row) => (
        <Badge variant="outline" className="text-xs font-normal">
          {row.department}
        </Badge>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      sortable: true,
      width: '120px',
      render: (row) => {
        const styles: Record<string, string> = {
          Active: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800',
          Pending: 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400 border-amber-200 dark:border-amber-800',
          Inactive: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-200 dark:border-slate-700',
        };
        return (
          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${styles[row.status]}`}>
            {row.status}
          </span>
        );
      },
    },
    {
      key: 'lastActive',
      header: 'Last Seen',
      sortable: true,
      render: (row) => <span className="text-xs text-muted-foreground">{row.lastActive}</span>,
    },
    {
      key: 'joinDate',
      header: 'Joined On',
      sortable: true,
      render: (row) => <span className="text-xs text-muted-foreground">{row.joinDate}</span>,
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      width: '90px',
      render: (row) => (
        <DropdownMenu>
          <DropdownMenuTrigger
            render={
              <Button variant="ghost" size="icon" className="h-8 w-8 cursor-pointer">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            }
          />
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Actions</DropdownMenuLabel>
            <DropdownMenuItem onClick={() => toast.info(`Viewing details for ${row.name}`)}>
              <Eye className="h-3.5 w-3.5 mr-2" /> View Details
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => toast.info(`Editing ${row.name}`)}>
              <Edit className="h-3.5 w-3.5 mr-2" /> Edit Record
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={() => handleDelete(row.id)}
              className="text-red-600 cursor-pointer"
            >
              <Trash2 className="h-3.5 w-3.5 mr-2" /> Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      {/* Page Title & Actions */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <TableIcon className="h-6 w-6 text-primary" />
            Reusable Table
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Full-featured data table template supporting sorting, filtering, selection, and export.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {selectedRows.length > 0 && (
            <Button
              variant="destructive"
              size="sm"
              onClick={handleBulkDelete}
              className="gap-1.5 cursor-pointer text-xs"
            >
              <Trash2 className="h-3.5 w-3.5" />
              Delete ({selectedRows.length})
            </Button>
          )}

          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setData(INITIAL_RECORDS);
              setSelectedRows([]);
              toast.info('Table data reset to initial records');
            }}
            className="gap-1.5 cursor-pointer text-xs"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Reset Data
          </Button>

          <Button
            size="sm"
            onClick={() => {
              const newId = `USR-${Math.floor(100 + Math.random() * 900)}`;
              const newRow: UserRecord = {
                id: newId,
                name: 'New Team Member',
                email: `user.${newId.toLowerCase()}@example.com`,
                role: 'Contributor',
                department: 'General',
                status: 'Active',
                lastActive: 'Just now',
                joinDate: new Date().toISOString().split('T')[0],
              };
              setData((prev) => [newRow, ...prev]);
              toast.success(`Created sample record ${newId}`);
            }}
            className="gap-1.5 cursor-pointer text-xs"
          >
            <Plus className="h-3.5 w-3.5" />
            Add Row
          </Button>
        </div>
      </div>

      {/* Main Table Card */}
      <Card className="shadow-xs border-slate-200 dark:border-slate-800">
        <CardContent className="p-0">
          <ReusableTable
            columns={columns}
            data={data}
            initialPageSize={10}
            showGear={true}
            selectable={true}
            selectedRows={selectedRows}
            onRowSelectChange={setSelectedRows}
            title="User Directory"
          />
        </CardContent>
      </Card>
    </div>
  );
}
