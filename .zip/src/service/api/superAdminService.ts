import { baseApi } from '../baseApi';
import { fetchFromApi } from '../apiClient';

// ----------------------------------------------------------------------
// DATA TYPES MATCHING superadminfe API
// ----------------------------------------------------------------------

export interface RevenueForecastTrendItem {
  month: string; // e.g. "2024-01" or "Jan 2024"
  mrr?: number;
  arr?: number;
}

export interface RevenueForecastData {
  current_mrr: number;
  current_arr: number;
  mrr_trend: Array<{ month: string; mrr: number }>;
  arr_trend: Array<{ month: string; arr: number }>;
}

export interface PaymentHighlightsData {
  total_invoiced: number;
  outstanding_amount: number;
  payment_success_rate: number;
  failed_payments: number;
  avg_payment_delay_days: number;
}

export interface TopPlansData {
  labels: string[];
  counts: number[];
}

export interface RenewalFunnelData {
  due_this_month: number;
  invoice_generated: number;
  payment_received: number;
  failed: number;
}

export interface RequestDistributionData {
  total_requests: number;
  invoice_generated_requests: number;
  pending_invoice_requests: number;
  instance_created: number;
  instance_pending: number;
  request_distribution: Array<{ module: string; count: number }>;
}

export interface PlanAdoptionData {
  total_active_subscriptions: number;
  trial_conversion_rate: number;
  plan_breakdown?: Array<{ plan_name: string; count: number; percentage: number }>;
}

export interface RenewalAnalyticsData {
  renewal_rate: number;
  upcoming_renewals_count: number;
  renewed_count: number;
}

export interface CancellationAnalyticsData {
  total_cancellations: number;
  churn_rate: number;
  reasons: Array<{ reason: string; count: number }>;
}

// SuperAdmin Overview Types
export interface SubscriptionAnalyticsData {
  active: number;
  trial: number;
  expired: number;
  renewal_rate: number;
  mrr?: number;
  arr?: number;
}

export interface SubscriptionInsightsData {
  churn_by_product: Array<{ product: string; total: number }>;
  growth_rate?: number;
  arpa?: number;
}

export interface UsageAnalyticsData {
  dau_trend: Array<{ date: string; active_users: number }>;
  total_storage_gb?: number;
  api_calls_today?: number;
}

export interface InstanceAnalyticsData {
  growth: Array<{ period: string; total: number; active: number }>;
  total_instances: number;
  healthy_count: number;
  avg_cpu_percent: number;
  avg_memory_percent: number;
}

// Form Types
export interface CreatePlanPayload {
  name: string;
  code: string;
  product: string;
  billing_cycle: 'Monthly' | 'Quarterly' | 'Yearly';
  price: number;
  currency: string;
  max_users: number;
  max_storage_gb: number;
  features: string[];
  is_active: boolean;
  description?: string;
}

export interface CreateSubscriptionPayload {
  account_id: string;
  account_name: string;
  plan_id: string;
  plan_name: string;
  start_date: string;
  expiry_date: string;
  billing_frequency: string;
  seats: number;
  discount_percentage: number;
  payment_status: 'Paid' | 'Pending' | 'Trial';
  auto_renew: boolean;
  notes?: string;
}

export interface CreateAccountPayload {
  company_name: string;
  subdomain: string;
  industry: string;
  contact_person: string;
  email: string;
  phone: string;
  country: string;
  state: string;
  city: string;
  postal_code?: string;
  initial_plan?: string;
  notes?: string;
}

// ----------------------------------------------------------------------
// FALLBACK MOCK DATA (High fidelity matching superadminfe)
// ----------------------------------------------------------------------

export const MOCK_REVENUE_FORECAST: RevenueForecastData = {
  current_mrr: 125000,
  current_arr: 1500000,
  mrr_trend: [
    { month: '2024-01', mrr: 88000 },
    { month: '2024-02', mrr: 94000 },
    { month: '2024-03', mrr: 102000 },
    { month: '2024-04', mrr: 110000 },
    { month: '2024-05', mrr: 118000 },
    { month: '2024-06', mrr: 125000 },
  ],
  arr_trend: [
    { month: '2024-01', arr: 1056000 },
    { month: '2024-02', arr: 1128000 },
    { month: '2024-03', arr: 1224000 },
    { month: '2024-04', arr: 1320000 },
    { month: '2024-05', arr: 1416000 },
    { month: '2024-06', arr: 1500000 },
  ],
};

export const MOCK_PAYMENT_HIGHLIGHTS: PaymentHighlightsData = {
  total_invoiced: 2845000.0,
  outstanding_amount: 142000.0,
  payment_success_rate: 98.4,
  failed_payments: 6,
  avg_payment_delay_days: 2.4,
};

export const MOCK_TOP_PLANS: TopPlansData = {
  labels: ['Enterprise Platinum', 'Business Pro', 'Growth Starter', 'Custom Solution'],
  counts: [142, 98, 64, 26],
};

export const MOCK_RENEWAL_FUNNEL: RenewalFunnelData = {
  due_this_month: 240,
  invoice_generated: 215,
  payment_received: 198,
  failed: 8,
};

export const MOCK_REQUEST_DISTRIBUTION: RequestDistributionData = {
  total_requests: 184,
  invoice_generated_requests: 126,
  pending_invoice_requests: 18,
  instance_created: 142,
  instance_pending: 12,
  request_distribution: [
    { module: 'Plan Upgrade', count: 72 },
    { module: 'Instance Scaling', count: 48 },
    { module: 'Addon Allocation', count: 64 },
  ],
};

export const MOCK_PLAN_ADOPTION: PlanAdoptionData = {
  total_active_subscriptions: 3840,
  trial_conversion_rate: 68.4,
  plan_breakdown: [
    { plan_name: 'Enterprise', count: 1420, percentage: 44 },
    { plan_name: 'Business Pro', count: 1180, percentage: 32 },
    { plan_name: 'Growth', count: 850, percentage: 18 },
    { plan_name: 'Custom', count: 390, percentage: 6 },
  ],
};

export const MOCK_RENEWAL_ANALYTICS: RenewalAnalyticsData = {
  renewal_rate: 94.2,
  upcoming_renewals_count: 320,
  renewed_count: 298,
};

export const MOCK_CANCELLATION_ANALYTICS: CancellationAnalyticsData = {
  total_cancellations: 42,
  churn_rate: 1.8,
  reasons: [
    { reason: 'Budget Constraints', count: 18 },
    { reason: 'Downsizing / Mergers', count: 12 },
    { reason: 'Migrated to Custom Stack', count: 8 },
    { reason: 'Other', count: 4 },
  ],
};

export const MOCK_SUBSCRIPTION_ANALYTICS: SubscriptionAnalyticsData = {
  active: 3840,
  trial: 420,
  expired: 86,
  renewal_rate: 94.2,
  mrr: 125000,
  arr: 1500000,
};

export const MOCK_SUBSCRIPTION_INSIGHTS: SubscriptionInsightsData = {
  churn_by_product: [
    { product: 'Enterprise Suite', total: 12 },
    { product: 'Business Cloud', total: 24 },
    { product: 'Starter Tier', total: 45 },
    { product: 'Custom Plan', total: 8 },
  ],
  growth_rate: 18.5,
  arpa: 420,
};

export const MOCK_USAGE_ANALYTICS: UsageAnalyticsData = {
  dau_trend: [
    { date: 'Mon', active_users: 1420 },
    { date: 'Tue', active_users: 1680 },
    { date: 'Wed', active_users: 1890 },
    { date: 'Thu', active_users: 2100 },
    { date: 'Fri', active_users: 2450 },
    { date: 'Sat', active_users: 1750 },
    { date: 'Sun', active_users: 1620 },
  ],
  total_storage_gb: 4820,
  api_calls_today: 184500,
};

export const MOCK_INSTANCE_ANALYTICS: InstanceAnalyticsData = {
  growth: [
    { period: 'Jan', total: 110, active: 104 },
    { period: 'Feb', total: 135, active: 128 },
    { period: 'Mar', total: 160, active: 154 },
    { period: 'Apr', total: 195, active: 188 },
    { period: 'May', total: 230, active: 224 },
    { period: 'Jun', total: 275, active: 268 },
  ],
  total_instances: 275,
  healthy_count: 271,
  avg_cpu_percent: 34.2,
  avg_memory_percent: 58.7,
};

// ----------------------------------------------------------------------
// RTK QUERY ENDPOINTS DEFINITION
// ----------------------------------------------------------------------

export const superAdminApi = baseApi.injectEndpoints({
  endpoints: (builder) => ({
    // SuperAdmin Overview endpoints
    getSubscriptionAnalytics: builder.query<SubscriptionAnalyticsData, void>({
      query: () => 'superadmin/SubscriptionAnalyticsAPI/',
      transformResponse: (res: any) => res?.data || res || MOCK_SUBSCRIPTION_ANALYTICS,
    }),
    getSubscriptionInsights: builder.query<SubscriptionInsightsData, void>({
      query: () => 'superadmin/SubscriptionInsightsAPI/',
      transformResponse: (res: any) => res?.data || res || MOCK_SUBSCRIPTION_INSIGHTS,
    }),
    getUsageAnalytics: builder.query<UsageAnalyticsData, void>({
      query: () => 'superadmin/UsageAnalyticsAPI/',
      transformResponse: (res: any) => res?.data || res || MOCK_USAGE_ANALYTICS,
    }),
    getInstanceAnalytics: builder.query<InstanceAnalyticsData, void>({
      query: () => 'superadmin/InstanceAnalyticsAPI/',
      transformResponse: (res: any) => res?.data || res || MOCK_INSTANCE_ANALYTICS,
    }),

    // Analytics Dashboard endpoints (exact match to superadminfe)
    getRevenueForecastDashboard: builder.query<RevenueForecastData, void>({
      query: () => 'superadmin/RevenueForecastDashboard/',
      transformResponse: (res: any) => res?.data || res || MOCK_REVENUE_FORECAST,
    }),
    getPaymentDashboardAnalytics: builder.query<PaymentHighlightsData, void>({
      query: () => 'superadmin/PaymentDashboardAnalytics/',
      transformResponse: (res: any) => res?.data || res || MOCK_PAYMENT_HIGHLIGHTS,
    }),
    getRenewalDashboardAnalytics: builder.query<RenewalAnalyticsData, void>({
      query: () => 'superadmin/RenewalDashboardAnalytics/',
      transformResponse: (res: any) => res?.data || res || MOCK_RENEWAL_ANALYTICS,
    }),
    getRenewalFunnelAnalytics: builder.query<RenewalFunnelData, void>({
      query: () => 'superadmin/RenewalFunnelAnalytics/',
      transformResponse: (res: any) => res?.data || res || MOCK_RENEWAL_FUNNEL,
    }),
    getCancellationOverviewAnalytics: builder.query<CancellationAnalyticsData, void>({
      query: () => 'superadmin/CancellationOverviewAnalytics/',
      transformResponse: (res: any) => res?.data || res || MOCK_CANCELLATION_ANALYTICS,
    }),
    getPlanAdoptionDashboardAnalytics: builder.query<PlanAdoptionData, void>({
      query: () => 'superadmin/PlanAdoptionDashboardAnalytics/',
      transformResponse: (res: any) => res?.data || res || MOCK_PLAN_ADOPTION,
    }),
    getTopPlansDistributionAnalytics: builder.query<TopPlansData, void>({
      query: () => 'superadmin/TopPlansDistributionAnalytics/',
      transformResponse: (res: any) => res?.data || res || MOCK_TOP_PLANS,
    }),
    getRequestOperationsDashboard: builder.query<RequestDistributionData, void>({
      query: () => 'superadmin/RequestOperationsDashboard/',
      transformResponse: (res: any) => res?.data || res || MOCK_REQUEST_DISTRIBUTION,
    }),

    // Forms Dropdowns & Lists
    getProductDropdown: builder.query<Array<{ id: string | number; name: string }>, void>({
      query: () => 'superadmin/ProductDropdownAPI/',
      transformResponse: (res: any) =>
        Array.isArray(res?.data || res) ? (res.data || res) : [
          { id: '1', name: 'SuperAdmin Cloud' },
          { id: '2', name: 'CRM Enterprise' },
          { id: '3', name: 'ERP Core' },
          { id: '4', name: 'Analytics Pro' },
        ],
    }),
    getMenuList: builder.query<Array<{ id: string | number; title: string; category?: string }>, void>({
      query: () => 'auth/MenuWithoutPagination/',
      transformResponse: (res: any) =>
        Array.isArray(res?.data || res) ? (res.data || res) : [
          { id: '1', title: 'Dashboard & KPIs', category: 'Overview' },
          { id: '2', title: 'Customer / Tenant Management', category: 'Customer' },
          { id: '3', title: 'Subscription & Plans', category: 'Sales' },
          { id: '4', title: 'Analytics & Reporting', category: 'Analytics' },
          { id: '5', title: 'Security & Access Control', category: 'Settings' },
          { id: '6', title: 'Support & Tickets', category: 'Support' },
        ],
    }),
    getAccountsList: builder.query<Array<{ id: string | number; name: string; email: string }>, void>({
      query: () => 'superadmin/AccountFullList/?Is_Deleted=False',
      transformResponse: (res: any) =>
        Array.isArray(res?.data || res) ? (res.data || res) : [
          { id: 'acc-1', name: 'Apex Global Technologies', email: 'billing@apexglobal.io' },
          { id: 'acc-2', name: 'CloudTech Solutions Ltd', email: 'admin@cloudtech.com' },
          { id: 'acc-3', name: 'Nexus Logistics Corp', email: 'finance@nexuslogistics.com' },
          { id: 'acc-4', name: 'Starlight Retail Hub', email: 'ops@starlightretail.org' },
        ],
    }),
    getPlansList: builder.query<Array<{ id: string | number; name: string; price: number; currency: string }>, void>({
      query: () => 'superadmin/planlist/?page=1',
      transformResponse: (res: any) => {
        const raw = res?.data || res?.results || res;
        return Array.isArray(raw) ? raw : [
          { id: 'plan-1', name: 'Starter Tier ($49/mo)', price: 49, currency: 'USD' },
          { id: 'plan-2', name: 'Growth Pro ($199/mo)', price: 199, currency: 'USD' },
          { id: 'plan-3', name: 'Enterprise Platinum ($599/mo)', price: 599, currency: 'USD' },
        ];
      },
    }),
    getIndustryList: builder.query<Array<{ id: string | number; label: string }>, void>({
      query: () => 'useradmin/Userlookuplist/',
      transformResponse: (res: any) => {
        const raw = res?.data || res;
        return Array.isArray(raw) ? raw : [
          { id: 'ind-1', label: 'Information Technology & SaaS' },
          { id: 'ind-2', label: 'Financial Services & Banking' },
          { id: 'ind-3', label: 'Healthcare & Life Sciences' },
          { id: 'ind-4', label: 'Supply Chain & Manufacturing' },
          { id: 'ind-5', label: 'E-commerce & Retail' },
        ];
      },
    }),

    // Form Submissions
    createPlan: builder.mutation<any, CreatePlanPayload>({
      query: (payload) => ({
        url: 'superadmin/planCRUD/',
        method: 'POST',
        body: payload,
      }),
    }),
    createSubscription: builder.mutation<any, CreateSubscriptionPayload>({
      query: (payload) => ({
        url: 'superadmin/subscription/',
        method: 'POST',
        body: payload,
      }),
    }),
    createAccount: builder.mutation<any, CreateAccountPayload>({
      query: (payload) => ({
        url: 'superadmin/AccountCRUD/',
        method: 'POST',
        body: payload,
      }),
    }),
  }),
});

export const {
  useGetSubscriptionAnalyticsQuery,
  useGetSubscriptionInsightsQuery,
  useGetUsageAnalyticsQuery,
  useGetInstanceAnalyticsQuery,
  useGetRevenueForecastDashboardQuery,
  useGetPaymentDashboardAnalyticsQuery,
  useGetRenewalDashboardAnalyticsQuery,
  useGetRenewalFunnelAnalyticsQuery,
  useGetCancellationOverviewAnalyticsQuery,
  useGetPlanAdoptionDashboardAnalyticsQuery,
  useGetTopPlansDistributionAnalyticsQuery,
  useGetRequestOperationsDashboardQuery,
  useGetProductDropdownQuery,
  useGetMenuListQuery,
  useGetAccountsListQuery,
  useGetPlansListQuery,
  useGetIndustryListQuery,
  useCreatePlanMutation,
  useCreateSubscriptionMutation,
  useCreateAccountMutation,
} = superAdminApi;
