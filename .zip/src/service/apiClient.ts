export function getTenantName(): string {
  if (typeof window === 'undefined') {
    return '';
  }
  const hostname = window.location.hostname;
  if (
    hostname === 'localhost' ||
    hostname === '127.0.0.1' ||
    hostname.startsWith('192.168.') ||
    hostname.includes('localhost')
  ) {
    return '';
  }
  const parts = hostname.split('.');
  if (parts.length > 2 && parts[0] !== 'www' && parts[0] !== 'superadmin') {
    return parts[0];
  }
  return '';
}

// Base API URL
export const BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'https://backend.crmfarm.app';
export const SHOW_ALL_MENUS = true;

/**
 * Generic Fetcher function designed for REST queries and TanStack Query `queryFn`.
 */
export async function fetchFromApi<T = any>(endpoint: string, options?: RequestInit): Promise<T> {
  const token =
    typeof window !== 'undefined'
      ? localStorage.getItem('token') || localStorage.getItem('accesstoken') || localStorage.getItem('access_token')
      : null;
  const tenant = getTenantName();

  const headers = new Headers(options?.headers);
  if (options?.body && !headers.has('Content-Type') && !(typeof FormData !== 'undefined' && options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  const noAuth = headers.get('X-No-Auth') === 'true';
  headers.delete('X-No-Auth');

  if (!noAuth && token && token !== 'null' && token !== 'undefined') {
    if (!headers.has('Authorization')) {
      headers.set('Authorization', `Bearer ${token}`);
    }
  }

  if (tenant && !headers.has('db')) {
    headers.set('db', tenant);
  }

  const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  const isSuperAdmin =
    cleanEndpoint.startsWith('/superadmin') ||
    cleanEndpoint.startsWith('/auth') ||
    cleanEndpoint.startsWith('/useradmin') ||
    cleanEndpoint.startsWith('/user');

  const rootUrl = BASE_URL.endsWith('/') ? BASE_URL.slice(0, -1) : BASE_URL;
  const url = !isSuperAdmin && tenant ? `${rootUrl}/${tenant}${cleanEndpoint}` : `${rootUrl}${cleanEndpoint}`;

  const res = await fetch(url, {
    credentials: 'omit',
    ...options,
    headers,
  });

  if (!res.ok) {
    if (res.status === 401 && typeof window !== 'undefined') {
      localStorage.removeItem('token');
      localStorage.removeItem('accesstoken');
      localStorage.removeItem('refreshToken');
    }

    let errorDetail = '';
    try {
      const errData = await res.clone().json();
      errorDetail = errData.detail || errData.message || errData.error || JSON.stringify(errData);
    } catch {
      try {
        errorDetail = await res.clone().text();
      } catch {}
    }

    throw new Error(`API error (${res.status}): ${errorDetail || res.statusText}`);
  }

  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch {
    return text as unknown as T;
  }
}
