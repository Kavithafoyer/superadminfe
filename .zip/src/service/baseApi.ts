import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

// Safe tenant / workspace extraction for both SSR and client-side
export const getTenantName = (): string => {
  if (typeof window === 'undefined') return '';
  const hostname = window.location.hostname;
  if (
    hostname === 'localhost' ||
    hostname === '127.0.0.1' ||
    hostname.startsWith('192.168.') ||
    hostname.includes('localhost')
  ) {
    return '';
  }
  const parts = hostname.split('.');
  if (parts.length > 2 && parts[0] !== 'www' && parts[0] !== 'superadmin') {
    return parts[0];
  }
  return '';
};

/**
 * Base RTK Query API slice for the application.
 * SuperAdmin and global platform APIs resolve directly to the root host (e.g. https://backend.crmfarm.app/superadmin/...)
 */
export const baseApi = createApi({
  reducerPath: "baseApi",
  baseQuery: async (args, api, extraOptions) => {
    const tenantName = getTenantName();
    const rawApiHost = process.env.NEXT_PUBLIC_API_URL || 'https://backend.crmfarm.app';
    const apiHost = rawApiHost.endsWith('/') ? rawApiHost.slice(0, -1) : rawApiHost;

    const endpointStr = typeof args === 'string' ? args : args.url || '';
    const cleanEndpoint = endpointStr.startsWith('/') ? endpointStr.slice(1) : endpointStr;
    const isSuperAdminRoute =
      cleanEndpoint.startsWith('superadmin') ||
      cleanEndpoint.startsWith('auth') ||
      cleanEndpoint.startsWith('useradmin') ||
      cleanEndpoint.startsWith('user');

    const baseUrl = !isSuperAdminRoute && tenantName ? `${apiHost}/${tenantName}/` : `${apiHost}/`;

    const rawBaseQuery = fetchBaseQuery({
      baseUrl,
      prepareHeaders: (headers) => {
        if (tenantName) {
          headers.set("db", tenantName);
        }
        if ((extraOptions as any)?.skipAuth) return headers;
        if (typeof window !== 'undefined') {
          const token =
            localStorage.getItem("token") ||
            localStorage.getItem("accesstoken") ||
            localStorage.getItem("access_token") ||
            "";
          if (token && token !== 'null' && token !== 'undefined') {
            headers.set("Authorization", `Bearer ${token}`);
          }
        }
        return headers;
      },
    });

    return rawBaseQuery(args, api, extraOptions);
  },
  tagTypes: ["User", "Profile", "Settings", "Items", "SuperAdmin"],
  endpoints: () => ({}),
});

// Backward compatibility alias
export const crmBaseApi = baseApi;
