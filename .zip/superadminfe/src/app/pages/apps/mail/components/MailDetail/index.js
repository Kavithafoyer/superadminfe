export {default} from './MailDetail';
