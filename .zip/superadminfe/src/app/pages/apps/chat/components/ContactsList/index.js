export {default} from "./ContactsList";
