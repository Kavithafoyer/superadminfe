export {default} from "./ChatGlobalSearch";
