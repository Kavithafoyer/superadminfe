export {default} from "./CardIconText";
